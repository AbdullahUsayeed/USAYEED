# SPDX-License-Identifier: LGPL-2.1-or-later
# SPDX-FileNotice: Part of the LearnCad addon.
"""A deliberately small FreeCAD shell for beginners.

Hides the workbench selector, advanced toolbars, and workbench menus, and adds
two context-aware toolbars: one for modeling and one for sketching. Advanced UI
is one checkbox away in Setup.
"""

from __future__ import annotations

from typing import Any, Optional

from .compat import QtCore, QtGui, QtWidgets

from . import icons as toolbar_icons
from . import settings


FEATURES_BAR = "LearnCadSimpleBar"
SKETCH_BAR = "LearnCadSketchBar"
CUSTOM_BARS = {FEATURES_BAR, SKETCH_BAR}

_APPLIED = False
_TOOLBAR_STATE: dict[str, bool] = {}
_MENU_STATE: dict[str, bool] = {}
_COMBO_VISIBLE = True
_BARS: dict[str, Any] = {}
_WORKBENCH_CONNECTED = False
_WORKBENCH_HANDLER = None
_HIDDEN_TABS = []
_HIDDEN_DOCKS = []
_MENUBAR_VISIBLE = True
_STATUSBAR_VISIBLE = True


def _gui():
    import FreeCADGui as Gui

    return Gui


def _main_window():
    try:
        return _gui().getMainWindow()
    except Exception:
        return None


def _action(parent, text: str, tooltip: str, callback) -> QtGui.QAction:
    action = QtGui.QAction(text, parent)
    action.setToolTip(tooltip)
    action.setStatusTip(tooltip)
    action.triggered.connect(lambda checked=False: callback())
    return action


def _raise_tools() -> None:
    """Bring the task/value panel forward when a command opens a dialog."""
    try:
        import FreeCADGui as Gui

        for dock in Gui.getMainWindow().findChildren(QtWidgets.QDockWidget):
            title = dock.windowTitle().strip().lower()
            if title in ("task", "tasks", "tool", "tools", "inspector"):
                dock.show()
                dock.raise_()
                break
    except Exception:
        pass


def _run(command: str) -> None:
    Gui = _gui()
    try:
        if command.startswith("PartDesign_"):
            Gui.activateWorkbench("PartDesignWorkbench")
        elif command.startswith("Sketcher_"):
            Gui.activateWorkbench("SketcherWorkbench")
        Gui.runCommand(command)
        if command.startswith(("PartDesign_", "Sketcher_Constrain")):
            QtCore.QTimer.singleShot(250, _raise_tools)
    except Exception:
        pass


def _pad_dialog() -> None:
    try:
        from . import panel

        panel.show_pad_dialog()
    except Exception:
        pass


def _new_sketch() -> None:
    """Start a sketch on the XY plane without a hidden plane-picker dead end."""
    try:
        from . import actions

        try:
            Gui = _gui()
            Gui.Control.closeDialog()
        except Exception:
            pass
        actions.new_part(None)
        # Bring the task tab forward so Sketch Edit / Constraints are visible.
        try:
            import FreeCADGui as Gui

            for dock in Gui.getMainWindow().findChildren(QtWidgets.QDockWidget):
                title = dock.windowTitle().strip().lower()
                if title in ("task", "tasks", "tool", "tools", "inspector"):
                    dock.show()
                    dock.raise_()
                    break
        except Exception:
            pass
    except Exception:
        pass


def _panel_call(method: str) -> None:
    try:
        from . import panel

        panel.show_panel()
        if panel._PANEL is not None:
            getattr(panel._PANEL, method)()
    except Exception:
        pass


def _build_features_bar(mw) -> None:
    bar = QtWidgets.QToolBar("LearnCad", mw)
    bar.setObjectName(FEATURES_BAR)
    bar.setMovable(False)
    bar.setFloatable(False)
    bar.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
    bar.setIconSize(QtCore.QSize(20, 20))

    def add(text, tip, callback, icon_name=None):
        action = _action(bar, text, tip, callback)
        if icon_name:
            action.setIcon(toolbar_icons.icon(icon_name))
        bar.addAction(action)

    add("New", "New document", lambda: _run("Std_New"), "new")
    add("Open", "Open a model", lambda: _run("Std_Open"), "open")
    add("Save", "Save the document", lambda: _run("Std_Save"), "save")
    bar.addSeparator()
    add("Undo", "Undo", lambda: _run("Std_Undo"), "undo")
    add("Redo", "Redo", lambda: _run("Std_Redo"), "redo")
    add("Fit", "Fit the model in the view", lambda: _run("Std_ViewFitAll"), "fit")
    bar.addSeparator()
    add("Sketch", "Create a sketch on the active body", _new_sketch, "sketch")
    add("Pad", "Pad the sketch and set its length", _pad_dialog, "pad")
    add("Pocket", "Pocket the selected sketch", lambda: _run("PartDesign_Pocket"), "pocket")
    add("Hole", "Add a hole", lambda: _run("PartDesign_Hole"), "hole")
    add("Fillet", "Round selected edges", lambda: _run("PartDesign_Fillet"), "fillet")
    add("Export", "Export STL or STEP", lambda: _run("Std_Export"), "export")
    bar.addSeparator()
    add("Render", "Render a studio preview", lambda: _run("CADet_RenderPreview"), "render")
    add("Studio", "Apply the LearnCad viewport look", lambda: _run("CADet_StudioLook"), "studio")
    add("Coach", "Open the LearnCad coach", lambda: _run("CADet_OpenMentor"), "coach")
    add("Setup", "LearnCad settings", lambda: _run("CADet_Settings"), "setup")
    mw.addToolBar(QtCore.Qt.TopToolBarArea, bar)
    _BARS[FEATURES_BAR] = bar


def _build_sketch_bar(mw) -> None:
    bar = QtWidgets.QToolBar("LearnCad Sketch", mw)
    bar.setObjectName(SKETCH_BAR)
    bar.setMovable(False)
    bar.setFloatable(False)
    bar.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
    bar.setIconSize(QtCore.QSize(20, 20))

    def add(text, tip, callback, icon_name=None):
        action = _action(bar, text, tip, callback)
        if icon_name:
            action.setIcon(toolbar_icons.icon(icon_name))
        bar.addAction(action)

    add("Undo", "Undo", lambda: _run("Std_Undo"), "undo")
    add("Redo", "Redo", lambda: _run("Std_Redo"), "redo")
    add("Fit", "Fit the sketch", lambda: _run("Std_ViewFitAll"), "fit")
    bar.addSeparator()
    add("Rect", "Draw a rectangle", lambda: _run("Sketcher_CreateRectangle"), "rect")
    add("Circle", "Draw a circle", lambda: _run("Sketcher_CreateCircle"), "circle")
    add("Line", "Draw connected lines", lambda: _run("Sketcher_CreatePolyline"), "line")
    bar.addSeparator()
    add("Coincident", "Join two points", lambda: _run("Sketcher_ConstrainCoincident"), "coincident")
    add("Horizontal", "Make a line horizontal", lambda: _run("Sketcher_ConstrainHorizontal"), "horizontal")
    add("Vertical", "Make a line vertical", lambda: _run("Sketcher_ConstrainVertical"), "vertical")
    add("Dimension", "Add a distance dimension", lambda: _run("Sketcher_ConstrainDistance"), "dimension")
    add("Radius", "Add a radius dimension", lambda: _run("Sketcher_ConstrainRadius"), "radius")
    bar.addSeparator()
    add("Coach", "Open the LearnCad coach", lambda: _run("CADet_OpenMentor"), "coach")
    add("Done", "Finish the sketch and return to the model", lambda: _run("Sketcher_LeaveSketch"), "leave")
    mw.addToolBarBreak(QtCore.Qt.TopToolBarArea)
    mw.addToolBar(QtCore.Qt.TopToolBarArea, bar)
    _BARS[SKETCH_BAR] = bar


def _ensure_bars(mw) -> None:
    for name, builder in ((FEATURES_BAR, _build_features_bar), (SKETCH_BAR, _build_sketch_bar)):
        bar = mw.findChild(QtWidgets.QToolBar, name)
        if bar is None:
            builder(mw)
        else:
            _BARS[name] = bar


def _in_sketch() -> bool:
    Gui = _gui()
    try:
        wb = Gui.activeWorkbench()
        if "sketcher" in str(getattr(wb, "MenuText", "")).lower():
            return True
    except Exception:
        pass
    try:
        gdoc = Gui.activeDocument()
        return gdoc is not None and gdoc.getInEdit() is not None
    except Exception:
        return False


def _sync_bars() -> None:
    sketch = _in_sketch()
    features = _BARS.get(FEATURES_BAR)
    sketch_bar = _BARS.get(SKETCH_BAR)
    if features is not None:
        features.setVisible(True)
    if sketch_bar is not None:
        sketch_bar.setVisible(sketch)


def _hide_default_toolbars(mw) -> None:
    global _COMBO_VISIBLE
    for bar in mw.findChildren(QtWidgets.QToolBar):
        name = bar.objectName()
        if name in CUSTOM_BARS:
            # Keep the main toolbar visible even while a sketch is open, so
            # Pad, Hole, Export and the rest never disappear.
            bar.setVisible(True if name == FEATURES_BAR else _in_sketch())
            continue
        if bar.isVisible():
            _TOOLBAR_STATE[name] = True
        bar.setVisible(False)
    # The workbench selector is a combo box inside the Workbench toolbar.
    for combo in mw.findChildren(QtWidgets.QComboBox):
        if "workbench" in (combo.toolTip() or "").lower():
            _COMBO_VISIBLE = combo.isVisible()
            combo.setVisible(False)


def _hide_menus(mw) -> None:
    global _MENUBAR_VISIBLE, _STATUSBAR_VISIBLE
    try:
        _MENUBAR_VISIBLE = mw.menuBar().isVisible()
        mw.menuBar().setVisible(False)
    except Exception:
        pass
    try:
        _STATUSBAR_VISIBLE = mw.statusBar().isVisible()
        mw.statusBar().setVisible(False)
    except Exception:
        pass


def _simplify_docks(mw) -> None:
    for tabs in mw.findChildren(QtWidgets.QTabWidget):
        labels = [tabs.tabText(i) for i in range(tabs.count())]
        if "Report view" not in labels:
            continue
        index = labels.index("Report view")
        try:
            if not tabs.tabBar().isTabVisible(index):
                continue
        except Exception:
            pass
        if "Model" in labels:
            try:
                tabs.setCurrentIndex(labels.index("Model"))
            except Exception:
                pass
        try:
            tabs.tabBar().setTabVisible(index, False)
            _HIDDEN_TABS.append((tabs, index))
        except Exception:
            pass
    for dock in mw.findChildren(QtWidgets.QDockWidget):
        title = dock.windowTitle().strip().lower()
        if "report" in title and dock.isVisible():
            _HIDDEN_DOCKS.append(dock)
            dock.setVisible(False)
        elif title == "model" and dock.isVisible():
            _HIDDEN_DOCKS.append(dock)
            dock.setVisible(False)


def _restore_docks() -> None:
    for tabs, index in _HIDDEN_TABS:
        try:
            tabs.tabBar().setTabVisible(index, True)
        except Exception:
            pass
    _HIDDEN_TABS.clear()
    for dock in _HIDDEN_DOCKS:
        try:
            dock.setVisible(True)
        except Exception:
            pass
    _HIDDEN_DOCKS.clear()


def _on_workbench(_name=None) -> None:
    if not settings.load().get("simple_mode", True):
        return
    QtCore.QTimer.singleShot(200, apply)


def apply() -> None:
    global _APPLIED, _WORKBENCH_CONNECTED
    if not settings.load().get("simple_mode", True):
        return
    mw = _main_window()
    if mw is None:
        return
    _ensure_bars(mw)
    _hide_default_toolbars(mw)
    _hide_menus(mw)
    _simplify_docks(mw)
    _sync_bars()
    if not _WORKBENCH_CONNECTED:
        try:
            mw.workbenchActivated.connect(_on_workbench)
            _WORKBENCH_CONNECTED = True
        except Exception:
            pass
    _APPLIED = True


def restore() -> None:
    global _APPLIED, _COMBO_VISIBLE
    mw = _main_window()
    if mw is None:
        return
    for name, visible in _TOOLBAR_STATE.items():
        bar = mw.findChild(QtWidgets.QToolBar, name)
        if bar is not None:
            bar.setVisible(visible)
    try:
        mw.menuBar().setVisible(True)
    except Exception:
        pass
    try:
        mw.statusBar().setVisible(True)
    except Exception:
        pass
    for combo in mw.findChildren(QtWidgets.QComboBox):
        if "workbench" in (combo.toolTip() or "").lower():
            combo.setVisible(_COMBO_VISIBLE)
    for name in CUSTOM_BARS:
        bar = mw.findChild(QtWidgets.QToolBar, name)
        if bar is not None:
            bar.setVisible(False)
    _restore_docks()
    _APPLIED = False


def toggle() -> None:
    current = bool(settings.load().get("simple_mode", True))
    config = settings.load()
    config["simple_mode"] = not current
    settings.save(config)
    if config["simple_mode"]:
        apply()
    else:
        restore()


def schedule() -> None:
    if not settings.load().get("simple_mode", True):
        return
    for delay in (1500, 4500, 7500):
        QtCore.QTimer.singleShot(delay, apply)
