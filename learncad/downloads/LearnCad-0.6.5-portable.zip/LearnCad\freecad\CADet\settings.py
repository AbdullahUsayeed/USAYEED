# SPDX-License-Identifier: LGPL-2.1-or-later
# SPDX-FileNotice: Part of the CADet addon.
"""Local configuration. Nothing is enabled by default except the deterministic
mentor, which never needs the network.
"""

from __future__ import annotations

import base64
import json
import os
from typing import Any

import FreeCAD as App

from . import secret_store


DEFAULTS: dict[str, Any] = {
    "ai_enabled": True,
    "base_url": "https://api.deepseek.com/v1",
    "model": "deepseek-flash",
    "api_key_enc": "",
    "consent_ai": True,
    "poll_ms": 900,
    "max_history": 12,
    "goal": "",
    "blender_path": "",
    "render_engine": "CYCLES",
    "render_resolution": [1200, 800],
    "render_samples": 64,
    "render_material": "aluminum",
    "simple_mode": True,
    "auto_open_panel": True,
    "navigation_style": "Gui::OpenInventorNavigationStyle",
}


PROVISION_FILE = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "resources", "ai_provision.dat"
)


def _provisioned_key() -> str:
    try:
        raw = base64.b64decode(open(PROVISION_FILE, "rb").read().strip())
        return bytes(byte ^ 0x5A for byte in raw).decode("utf-8").strip()
    except Exception:
        return ""


def is_managed() -> bool:
    return bool(_provisioned_key())


def _ensure_provision(data: dict[str, Any]) -> dict[str, Any]:
    """Install the bundled LearnCad AI key once, encrypted for this user."""
    key = _provisioned_key()
    if not key:
        return data
    try:
        data["base_url"] = "https://api.deepseek.com/v1"
        data["model"] = "deepseek-flash"
        if not data.get("api_key_enc"):
            set_api_key(data, key)
            data["ai_enabled"] = True
            data["consent_ai"] = True
        save(data)
    except Exception:
        pass
    return data


def config_dir() -> str:
    try:
        base = App.getUserConfigDir()
    except Exception:
        base = App.getUserAppDataDir()
    path = os.path.join(base, "LearnCad")
    os.makedirs(path, exist_ok=True)
    return path


def config_path() -> str:
    return os.path.join(config_dir(), "config.json")


def load() -> dict[str, Any]:
    path = config_path()
    data: dict[str, Any] = dict(DEFAULTS)
    try:
        if os.path.isfile(path):
            with open(path, "r", encoding="utf-8") as handle:
                loaded = json.load(handle)
            if isinstance(loaded, dict):
                data.update(loaded)
    except Exception:
        pass
    return _ensure_provision(data)


def save(data: dict[str, Any]) -> None:
    path = config_path()
    payload = dict(DEFAULTS)
    payload.update(data or {})
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True)
    os.replace(tmp, path)
    secret_store.harden_file(path)


def get_api_key(data: dict[str, Any]) -> str:
    return secret_store.unprotect(str(data.get("api_key_enc", "") or ""))


def set_api_key(data: dict[str, Any], key: str) -> None:
    data["api_key_enc"] = secret_store.protect(key or "")


def ai_ready(data: dict[str, Any]) -> bool:
    if not data.get("ai_enabled"):
        return False
    if not data.get("base_url") or not data.get("model"):
        return False
    if not data.get("consent_ai"):
        return False
    key = get_api_key(data)
    base = str(data.get("base_url", "")).lower()
    if key:
        return True
    # Local providers (Ollama, LM Studio) commonly accept an empty key.
    return any(host in base for host in ("localhost", "127.0.0.1", "0.0.0.0"))


def masked_key(data: dict[str, Any]) -> str:
    key = get_api_key(data)
    if not key:
        return "(not set)"
    if len(key) <= 8:
        return "*" * len(key)
    return key[:4] + "..." + key[-4:]
