# SPDX-License-Identifier: LGPL-2.1-or-later
# SPDX-FileNotice: Part of the CADet addon.
"""Optional AI explanation layer.

The deterministic mentor in analysis.py is the source of truth. This module
only sends a compact, explicit summary of the model to an OpenAI-compatible
endpoint when the user has opted in.
"""

from __future__ import annotations

import json
import urllib.error
import urllib.request
from typing import Any

from . import settings
from .guide import APP_GUIDE
from .model import Analysis, Snapshot


class AIClientError(RuntimeError):
    pass


SYSTEM_PROMPT = """You are LearnCad, a senior mechanical engineer and CAD coach mentoring a beginner inside the LearnCad application.

You can see the live document state and a deterministic engineering review. Use those facts for model questions. Use the LearnCad app guide for how-to questions.

=== LEARNCAD APP GUIDE (the complete beginner-facing UI) ===
""" + APP_GUIDE + """

=== RULES ===
- The user's stated goal is in the context. Review the model against that goal, not just against generic best practice.
- Never invent dimensions, constraints, or object names. If a number is not in the context, say so.
- When a sketch is under-constrained, explain the exact missing constraint and the order to add it.
- Praise only when the model has earned it.
- Warn about consequences: printability, rebuildability, stress concentration, tolerance.
- The user is learning. Explain the why, not just the click.
- For "how do I...", "where is...", or "which button..." questions, use the exact LearnCad labels from the app guide and give a short numbered sequence. Do not mention the underlying CAD engine, its menus, workbenches, version, or the renderer. Never send the user to a menu that is not in the guide.
- If the guide does not cover a control, say that Simple Mode exposes the listed tools and that Setup can restore the advanced workspace.
- Do not write code unless the user asks. If asked, keep it short and use the standard Python console API.
- If the intent is ambiguous, ask one clarifying question instead of guessing.
- Keep UI answers under 200 words unless the user asks for a full walkthrough.
- Never reveal, confirm, deny, or discuss the model, provider, vendor, version, parameter count, or underlying technology. If asked, say only that you are LearnCad's built-in coach and redirect to the user's CAD question. Never output a model ID, provider name, or vendor name.
- No fluff, no "as an AI", no long introductions.
"""


def _compact_snapshot(snapshot: Snapshot) -> dict[str, Any]:
    if snapshot.doc is None:
        return {"document": None}
    doc = snapshot.doc
    bodies = []
    for body in doc.bodies[:3]:
        bodies.append({
            "label": body.label,
            "tip": body.tip,
            "feature_count": body.feature_count,
            "error_count": body.error_count,
            "valid": body.shape_valid,
            "closed": body.shape_closed,
            "volume": round(body.volume, 1),
            "bbox": [round(v, 1) for v in body.bbox.dims],
            "features": [
                {
                    "label": f.label,
                    "type": f.type_id,
                    "state": f.state,
                    "valid": f.valid,
                    "length": f.length,
                    "radius": f.radius,
                    "diameter": f.diameter,
                }
                for f in body.features[:12]
            ],
        })
    sketches = []
    for sketch in doc.sketches[:6]:
        sketches.append({
            "label": sketch.label,
            "dof": sketch.dof,
            "fully_constrained": sketch.fully_constrained,
            "geometry_count": sketch.geometry_count,
            "constraint_count": sketch.constraint_count,
            "wires": [sketch.total_wires, sketch.open_wires],
            "conflicts": [sketch.conflicting, sketch.redundant, sketch.malformed],
            "missing": {
                "coincident": sketch.missing_coincident,
                "horizontal_vertical": sketch.missing_hv,
                "radius": sketch.missing_radius,
                "equality": sketch.missing_equality,
            },
            "attached": sketch.attached,
            "support": sketch.support,
            "bbox": [round(v, 1) for v in sketch.bbox.dims],
            "dimensions": [
                {"kind": d.kind, "value": round(d.value, 2)}
                for d in sketch.dimensions[:20]
            ],
        })
    return {
        "goal": snapshot.goal,
        "document": {
            "label": doc.label,
            "workbench": doc.workbench,
            "edit_mode": doc.edit_mode,
            "active_object": doc.active_object,
            "selection": {
                "object": doc.selection.object_label or doc.selection.object_name,
                "type": doc.selection.object_type,
                "subelements": doc.selection.subelements[:6],
            },
            "object_count": doc.object_count,
            "units": doc.units,
            "bodies": bodies,
            "sketches": sketches,
            "standalone_features": [
                {"label": f.label, "type": f.type_id, "valid": f.valid}
                for f in doc.features[:8]
            ],
        }
    }


def build_payload(
    question: str,
    snapshot: Snapshot,
    analysis: Analysis,
    model: str,
    history: list[dict[str, str]] | None = None,
) -> dict[str, Any]:
    context = {
        "project": _compact_snapshot(snapshot),
        "review": analysis.to_dict(),
        "question": question,
    }
    user_text = (
        "Here is the live project context and the deterministic review. "
        "For model-specific questions, answer from these facts. "
        "For how-to or UI questions, answer from the LEARNCAD APP GUIDE in the system prompt. "
        "Do not use any other menu names.\n\n"
        + json.dumps(context, ensure_ascii=False, default=str)
    )
    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    for item in history or []:
        role = str(item.get("role", ""))
        content = str(item.get("content", "") or "").strip()
        if role in ("user", "assistant") and content:
            messages.append({"role": role, "content": content})
    messages.append({"role": "user", "content": user_text})
    return {
        "model": model,
        "temperature": 0.2,
        "max_tokens": 650,
        "messages": messages,
    }


def _extract_text(payload: dict[str, Any]) -> str:
    if isinstance(payload.get("choices"), list) and payload["choices"]:
        message = payload["choices"][0].get("message", {})
        content = message.get("content", "")
        if isinstance(content, str):
            return content.strip()
        if isinstance(content, list):
            parts = []
            for block in content:
                if isinstance(block, dict) and block.get("type") == "text":
                    parts.append(str(block.get("text", "")))
            return "\n".join(parts).strip()
    if isinstance(payload.get("content"), list):
        parts = [str(block.get("text", "")) for block in payload["content"] if isinstance(block, dict)]
        return "\n".join(parts).strip()
    if isinstance(payload.get("response"), str):
        return payload["response"].strip()
    return ""


def ask(
    data: dict[str, Any],
    question: str,
    snapshot: Snapshot,
    analysis: Analysis,
    history: list[dict[str, str]] | None = None,
) -> str:
    if not settings.ai_ready(data):
        raise AIClientError("AI is not enabled. LearnCad's local mentor still works without it.")

    base_url = str(data.get("base_url", "")).rstrip("/")
    model = str(data.get("model", "")).strip()
    key = settings.get_api_key(data)
    payload = build_payload(question, snapshot, analysis, model, history)
    body = json.dumps(payload).encode("utf-8")

    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    if key:
        headers["Authorization"] = f"Bearer {key}"

    request = urllib.request.Request(base_url + "/chat/completions", data=body, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(request, timeout=60) as response:
            raw = response.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as exc:
        detail = ""
        try:
            detail = exc.read().decode("utf-8", errors="replace")[:500]
        except Exception:
            pass
        raise AIClientError(f"Provider returned HTTP {exc.code}. {detail}".strip()) from exc
    except urllib.error.URLError as exc:
        raise AIClientError(f"Could not reach the AI provider: {exc.reason}") from exc
    except TimeoutError as exc:
        raise AIClientError("The AI provider timed out after 60 seconds.") from exc

    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise AIClientError("The provider returned a response that was not JSON.") from exc

    text = _extract_text(parsed)
    if not text:
        raise AIClientError("The provider returned an empty answer.")
    return text


def test_connection(data: dict[str, Any]) -> tuple[bool, str]:
    if not data.get("base_url") or not data.get("model"):
        return False, "Set a base URL and model first."
    if not data.get("consent_ai"):
        return False, "Enable the AI privacy consent first."
    base_url = str(data.get("base_url", "")).rstrip("/")
    key = settings.get_api_key(data)
    headers = {"Accept": "application/json"}
    if key:
        headers["Authorization"] = f"Bearer {key}"
    request = urllib.request.Request(base_url + "/models", headers=headers, method="GET")
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            if 200 <= response.status < 300:
                return True, "Connected. The provider accepted the request."
    except urllib.error.HTTPError as exc:
        if exc.code == 401:
            return False, "The provider rejected the API key (401)."
        if exc.code == 404:
            return True, "The provider is reachable (no /models endpoint, which is normal for some servers)."
        return False, f"The provider returned HTTP {exc.code}."
    except Exception as exc:
        return False, f"Could not reach the provider: {exc}"
    return False, "The provider did not return a success status."
